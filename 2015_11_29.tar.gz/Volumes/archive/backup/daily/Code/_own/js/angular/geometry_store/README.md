# Geometry Store

A simple [Angular.js](https://angularjs.org/) application inspired by the _"Shaping up with Angular.js"_ course at [CodeSchool](https://www.codeschool.com/).