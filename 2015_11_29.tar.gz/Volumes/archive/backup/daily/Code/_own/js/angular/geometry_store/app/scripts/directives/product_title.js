'use strict';
app.directive('productTitle', function() {
  return {
    restrict: 'E',
    templateUrl: 'partials/product-title.html'
  }
})