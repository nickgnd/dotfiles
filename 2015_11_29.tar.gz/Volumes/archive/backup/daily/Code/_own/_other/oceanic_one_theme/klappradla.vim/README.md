# klappradla.vim
my vim color scheme

My color scheme, **klappradla**, inspired by the awesome [memco Oceanic](https://github.com/memco/Oceanic-tmTheme) and [atom one dark](https://github.com/atom/one-dark-syntax) themes.

![Alt text](img/ruby.png?raw=true)