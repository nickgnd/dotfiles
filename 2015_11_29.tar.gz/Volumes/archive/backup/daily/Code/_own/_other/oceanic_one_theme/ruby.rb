require 'gem'

# The Greeter class
class Greeter
  def initialize(attributes = {})
    @name = attributes[:name].capitalize
  end

  def salute
    puts "Hello #{@name}!"
  end
end

# Create a new object
g = Greeter.new(name: 'world')

# Output "Hello World!"
g.salute